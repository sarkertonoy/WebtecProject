<?php

include("../Controller/header1.php");


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Form</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="./css/singin.css">
</head>
<body>
   
<div class="col-lg-offset-2 col-lg-6">
        <!-- login form -->
        <form name="signupForm" onsubmit="return validateForm()" action="" method="POST" >
		<br><br>			
        <center><h1><i>Login To The System</i></h1></center>
        <br><br>
					
					<div class="input-group">
						<span class="input-group-addon"><i >Email</i></span>
						<input  type="text" class="form-control" placeholder="Email" name="email" >
					</div>
					<div class="error" id="emailErr"></div>
					<br>
					<div class="input-group">
						<span class="input-group-addon"><i >Password</i></span>
						<input  type="password" class="form-control" placeholder="Password" name="password">
					</div>
					<div class="error" id="passwordErr"></div>
					<br>
                    <center><button id="login" class="btn btn-info btn-lg" name="login">Signin</button></center>
         	<?php include("../Controller/login.php"); ?>
				</form>

                

    </div>
    <script src="./js/login.js"></script>
</body>
</html>