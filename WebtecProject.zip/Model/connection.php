<?php
$con = mysqli_connect("localhost","root","","manager");
?>
