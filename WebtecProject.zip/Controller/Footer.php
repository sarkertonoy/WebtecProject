<html>
<head>
<style>
footer {
  text-align: center;
  padding: 3px;
  background-color: DarkSalmon;
  color: white;
}
</style>
</head>
<body>

<footer>
  <p>Author: Tonoy<br>
  <a href="mailto:tonoy@gamil.com">tonoy@gmail.com.com</a></p>
</footer>

</body>
</html>