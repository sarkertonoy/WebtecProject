<!DOCTYPE html>
<html>
<head>

	<title>Manager</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="./View/css/main.css">
	
</head>

<body>
<div class="main-div">

	<br><br>
	<div class="row">
		
		<div class="col-sm-6" style="left:8%:">
			<h2><strong>Welcome Manager Of The System </strong></h2><br><br>
			<h4><strong>Join By Login.</strong></h4>
			<form method="post" action="">
				
				<button id="login" class="btn btn-info btn-lg" name="login">Login</button><br><br>
				<?php
					if(isset($_POST['login'])){
						echo "<script>window.open('./View/signin.php','_self')</script>";
					}
				?>
			</form>
		</div>
	</div>
	</div>
</body>
</html>
