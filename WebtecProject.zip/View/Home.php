
<?php
session_start();
include("../Model/connection.php");
include("../Controller/header.php");
if(!isset($_SESSION['user_email'])){
	header("location: index.php");
}

?>
<?php
		$user = $_SESSION['user_email'];
		$get_user = "select * from user where email='$user'";
		$run_user = mysqli_query($con,$get_user);
		$row = mysqli_fetch_array($run_user);

		$user_name = $row['f_name'];
	?>
<?php 

 

$select = "SELECT * FROM tourist";
$result = $con->query($select);
?> 

<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <title><?php echo "$user_name";?></title> 
	<link rel="stylesheet" type="text/css" href="./css/home_style2.css">

</head> 
<body> 
    <center>
        <h1>Welcome <?php echo "$user_name";?></h1>
       <br><br><br>
        <h3><i>Tourist Spot</i></h3>
    <div class="container">
		<table class="table">
			<thead class="thead-light">
			<tr>
			  <th scope="col">ID</th>
			  <th scope="col">Tourist Spot Name</th>
			  <th scope="col">Details</th>
             
			</tr>
			</thead>
			<tbody>
                         
                        <?php   
			// Loop the employee data
				echo '<table class="table table-bordered">';
				while($row = $result->fetch_object()){
					echo '<tr>'
						.'<td>'.$row->id.'</td>'
						.'<td>'.$row->t_name.'</td>'
						.'<td>'.$row->t_details.'</td>'
                        
						.'</tr>';
				}
				echo '</table>';
                        ?> 
			</tbody> 
        </table> 
		<br><br><br><br>
		<br><br><br><br>
		<br><br><br><br>
    </div> 
</body> 
<?php
		 include "../Controller/footer.php";
		 ?>
</html> 