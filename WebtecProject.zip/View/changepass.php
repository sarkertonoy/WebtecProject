<?php
include("../Model/connection.php");
include("../Controller/header1.php");

?>
<!DOCTYPE html>
<html>
<head>

	<title>Change Password</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="singin.css">
</head>
<style>
.error{
	color: red;
}
</style>
<body>
<div class="row">
  <div class="col-sm-2">
  </div>
  <div class="col-sm-8">
  	<form name="updateForm" onsubmit="return validateForm()" action="" method="post" enctype="multipart/form-data">
      <table class="table table-bordered table-hover">
    		<tr align="center">
    			<td colspan="6" class="active"><h2>Change Password</h2></td>
    		</tr>
            <tr>
    			<td style="font-weight: bold;"> Password</td>
    			<td>
    				<input  class="form-control" type="password" name="u_pass" id="mypass">
  						<div class="error" id="passwordErr"></div>
    			</td>
    		</tr>
    		
    		<tr>
    			<td style="font-weight: bold;">Confirm Password</td>
    			<td>
    				<input  class="form-control" type="password" name="u_pass1" id="mypass1" >
  						<div class="error" id="passwordErr1"></div>
    			</td>
    		</tr>
    		
  		<tr align="center">
  			<td colspan="6">
  				<input type="submit" class="btn btn-info" name="update" style="width:250px;" value="Update">
  			</td>
  		</tr>
  	</table>
  </form>
  </div>
  <script src="./js/pass.js"></script>
  <div class="col-sm-2">
  </div>
</div>

</body>
</html>
<?php

if (isset($_POST['update'])) {
	
	$u_pass = htmlentities($_POST['u_pass']);
    $u_pass1 = htmlentities($_POST['u_pass1']);


    if ($u_pass=='') {
         echo "<script>alert('Please enter valid password')</script>";
         echo "<script>window.open('changepass.php','_self')</script>";

         exit();
    }
    elseif ($u_pass1=='') {
        echo "<script>alert('Please enter valid Confirm password')</script>";
        echo "<script>window.open('changepass.php','_self')</script>";

        exit();
   }
   else {
    if($u_pass==$u_pass1){
        $update = "update user set pass='$u_pass'";
     $run= mysqli_query($con,$update);
      if ($run) {
        echo "<script>alert('Updating......')</script>";
        echo "<script>window.open('changepass.php','_self')</script>";
        // code...
      }
    }else{
        echo "<script>alert('Password doesnot match')</script>";
        echo "<script>window.open('changepass.php','_self')</script>";
    }
   
   }

}
	// code...


 ?>
