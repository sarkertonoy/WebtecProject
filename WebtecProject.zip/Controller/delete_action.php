<?php
include_once("../Model/connection.php");
if(isset($_POST['id'])) {
	$emp_id = trim($_POST['id']);	
	$sql = "DELETE FROM payment WHERE id in ($emp_id)";
	$resultset = mysqli_query($con, $sql) or die("database error:". mysqli_error($con));
	echo $emp_id;
}
?>