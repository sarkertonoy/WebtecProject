<!DOCTYPE html>

<?php
error_reporting(0);
session_start();
include("../Model/connection.php");
include("../Controller/header.php");
if(!isset($_SESSION['user_email'])){
	header("location: index.php");
}

?>

<html>
<head>
<title>Check Clients</title>
<meta content="noindex, nofollow" name="robots">
<link href="./css/style1.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="maindiv">
<div class="divA">
<div class="title">
<h2>Recent Client</h2>
</div>
<div class="divB">
<div class="divD">
<p>Client</p>
</div>
</div>

<?php

$get_user2 = "select * from client ";

$run_user2 = mysqli_query($con,$get_user2);
$row2 = mysqli_fetch_array($run_user2);
?>
<div class="form">
<h2>---Details---</h2>

<span>ID :</span> <?php echo $row2['id']; ?><br>
<lable><b>Name :</b></lable> <?php echo $row2['name']; ?><br>
<span>Address:</span> <?php echo $row2['address']; ?><br>
<span>Phone :</span> <?php echo $row2['phone']; ?><br>

</div>


</body>
</html>
