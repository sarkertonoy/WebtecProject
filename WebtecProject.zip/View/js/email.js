// Defining a function to display error message
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Defining a function to validate form
function validateForm() {
    // Retrieving the values of form elements
  
    var mail = document.signupForm.email.value;
  
  

    // Defining error variables with a default value
    var emailErr= true;

    // Validate first name
   

    // Validate last name
   

    // Validate email address
    if (mail == "") {
        printError("emailErr", "Please enter your email address");
    } else {
        var regex = /^\S+@\S+\.\S+$/;
        if (regex.test(mail) === false) {
            printError("emailErr", "Please enter a valid email address");
        } else {
            printError("emailErr", "");
            emailErr = false;
        }
    }

    // Validate password
 

   
    // Prevent the form from being submitted if there are any errors
    if ((emailErr) == true)
     {
        return false;
    }
    else {


    }
};
