<?php

if(count($_SESSION)===0){
  header("Location: logout.php");
}
 ?>
<?php
include("../Model/connection.php");

?>

		<?php
		$user = $_SESSION['user_email'];
		$get_user = "select * from user where email='$user'";
		$run_user = mysqli_query($con,$get_user);
		$row=mysqli_fetch_array($run_user);

		$user_id = $row['id'];
		$first_name = $row['f_name'];
		$last_name = $row['l_name'];
	
		$user_pass = $row['pass'];
		$user_email = $row['email'];
		$user_address = $row['address'];
		$user_mobile = $row['phone'];
		$user_image = $row['picture'];

		?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <style>
        .navbar{
            background-color: black;
            border-radius: 30px;
            
        }
        .navbar ul{
            overflow: auto;
        }
        .navbar li{
            float:left;
            list-style: none; 
            margin: 13px 20px;
            
        }
        .navbar li a{
            padding: 3px 3px;
            text-decoration: none;
            color: white;
        }
        .navbar li a:hover{
            color: red
        }
        .search{
            float: right;
            color: white;
            padding: 12px 75px;
        }
        .navbar input{
            border: 2px solid black;
            border-radius: 14px;
            padding: 3px 17px;
            width: 129px;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar">
            <ul>
                <li><a href="Home.php">Home</a></li>
                <li><a href="Employee.php">Employee Management</a></li>
                <li><a href="Check.php">Check Clients</a></li>
                <li><a href="Payment.php">Payments</a></li>
                <li><a href="edit.php">Edit Profile</a></li>
               
                <form class="navbar-form navbar-left" method="get" action="logout.php">
							<div class="form-group"

							</div>
							<button type="submit" style="width:80px;color:black;background-color:white;" class="btn btn-info" name="search">Logout </button>
						</form>
               
            </ul>
        </nav>
    </header>
</body>

</html>