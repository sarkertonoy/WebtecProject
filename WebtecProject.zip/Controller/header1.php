<link rel="stylesheet" type="text/css" href="../View/css/nav_bar.css">
<header>
    <div class="container">
      

      <nav>
        <ul>
            <center>
          <li><a href="signin.php">Login</a></li>
          <li><a href="register.php">Registration</a></li>
          <li><a href="emailvari.php">Forget Password</a></li>
        
        </ul>
      </nav>
    </div>
  </header>
