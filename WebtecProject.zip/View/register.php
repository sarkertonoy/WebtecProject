<?php

include("../Controller/header1.php");


?>

<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="./css/singin.css">
</head>

<body>
<div class="col-lg-offset-2 col-lg-6">
<div class="row">
	<div class="col-sm-8">
		<div class="main-content">
			<div class="header">
				<h3 style="text-align: center;"><strong>Registration</strong></h3>
				<hr>
			</div>
			<div class="l-part">
				<form name="signupForm" onsubmit="return validateForm()" action="" method="POST" >
					<div class="input-group">
                    <span class="input-group-addon"></span>
						<input type="text" class="form-control" placeholder="First Name" name="fname">

					</div>
					<div class="error" id="fnameErr"></div>
					<br>
					<div class="input-group">
                    <span class="input-group-addon"></span>
						<input type="text" class="form-control" placeholder="Last Name" name="lname">
					</div>
					<div class="error" id="lnameErr"></div>
					<br>
                    <div class="input-group">
                    <span class="input-group-addon"></span>
						<input type="text" class="form-control" placeholder="User Name" name="uname">
					</div>
					<div class="error" id="unameErr"></div>
					<br>
					<div class="input-group">
                    <span class="input-group-addon"></span>
						<input  type="email" class="form-control" placeholder="Email" name="email" >
					</div>
					<div class="error" id="emailErr"></div>
					<br>
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
						<input  type="password" class="form-control" placeholder="Password" name="password">
					</div>
					<div class="error" id="passwordErr"></div>
					<br>
					<div class="input-group">
				
                    <span class="input-group-addon"></span>
						<input type="text" class="form-control" placeholder="Address" name="address">
					</div>
					
					<div class="error" id="addErr"></div>
					<br>
                    <div class="input-group">
				
                    <span class="input-group-addon"></span>
                <input type="text" class="form-control" placeholder="Phone Number" name="phone">
            </div>
            
           
            <br>
					<div class="input-group">
                    <span class="input-group-addon"></span>
						<select class="form-control input-md" name="gender">
							<option>Select your Gender</option>
							<option>Male</option>
							<option>Female</option>
							<option>Others</option>
						</select>
					</div>
					<div class="error" id="genderErr"></div>
					<br>
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
						<input type="date" class="form-control input-md" placeholder="Email" name="u_birthday">
					</div><br>
					<center><button id="signup" class="btn btn-info btn-lg" name="sign_up">Signup</button></center>
         	<?php include("../Controller/insert_user.php"); ?>
				</form>
			</div>
		</div>
	</div>
</div>
</div>
<script src="./js/regis.js"></script>
</body>

</html>
