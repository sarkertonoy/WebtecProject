// Defining a function to display error message
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Defining a function to validate form
function validateForm() {
    // Retrieving the values of form elements
    var f_name = document.signupForm.fname.value;
    var l_name = document.signupForm.lname.value;
    var u_name = document.signupForm.uname.value;
    var mail = document.signupForm.email.value;
    var password = document.signupForm.password.value;
    var address = document.signupForm.address.value;
    var gender = document.signupForm.gender.value;
    
    // Defining error variables with a default value
    var fnameErr = lnameErr=unameErr =addErr= emailErr = genderErr =passwordErr= true;

    // Validate first name
    if (f_name == "") {
        printError("fnameErr", "Please enter your first name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(f_name) === false) {
            printError("fnameErr", "Please enter a valid first name");
        } else {
            printError("fnameErr", "");
            fnameErr = false;
        }
    }

    // Validate last name
    if (l_name == "") {
        printError("lnameErr", "Please enter your last name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(l_name) === false) {
            printError("lnameErr", "Please enter a valid last name");
        } else {
            printError("lnameErr", "");
            lnameErr = false;
        }
    }
    if (u_name == "") {
        printError("unameErr", "Please enter your user name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(u_name) === false) {
            printError("unameErr", "Please enter a valid user name");
        } else {
            printError("unameErr", "");
            unameErr = false;
        }
    }

    // Validate email address
    if (mail == "") {
        printError("emailErr", "Please enter your email address");
    } else {
        var regex = /^\S+@\S+\.\S+$/;
        if (regex.test(mail) === false) {
            printError("emailErr", "Please enter a valid email address");
        } else {
            printError("emailErr", "");
            emailErr = false;
        }
    }

    // Validate password
    if (password == "") {
        printError("passwordErr", "Please enter your password");
    } else {
        var regex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
        if (regex.test(password) === false) {
            printError("passwordErr", "Password should contain at least one number, one uppercase character and one special character");
        } else {
            printError("passwordErr", "");
            passwordErr = false;
        }
    }

    if (address == "") {
        printError("addErr", "Please enter your address");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(address) === false) {
            printError("addErr", "Please enter a valid address");
        } else {
            printError("addErr", "");
            addErr = false;
        }
    }

    // Validate gender
    if (gender == "Select") {
        printError("genderErr", "Please select your gender");
    } else {
        printError("genderErr", "");
        genderErr = false;
    }

    // Prevent the form from being submitted if there are any errors
    if ((fnameErr || lnameErr ||unameErr||addErr||passwordErr || emailErr  || countryErr || genderErr) == true)
     {
        return false;
    }
    else {


    }
};
