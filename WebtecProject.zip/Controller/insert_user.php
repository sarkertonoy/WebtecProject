<?php
include("../Model/connection.php");

	if(isset($_POST['sign_up'])){

		$first_name = htmlentities(mysqli_real_escape_string($con,$_POST['fname']));
		$last_name = htmlentities(mysqli_real_escape_string($con,$_POST['lname']));
        $user_name = htmlentities(mysqli_real_escape_string($con,$_POST['uname']));
		$pass = htmlentities(mysqli_real_escape_string($con,$_POST['password']));
		$email = htmlentities(mysqli_real_escape_string($con,$_POST['email']));
		$address = htmlentities(mysqli_real_escape_string($con,$_POST['address']));
		$gender = htmlentities(mysqli_real_escape_string($con,$_POST['gender']));
		$birthday = htmlentities(mysqli_real_escape_string($con,$_POST['u_birthday']));
        $phone = htmlentities(mysqli_real_escape_string($con,$_POST['phone']));



		
	

		if(strlen($pass) <9 ){
			echo"<script>alert('Password should be minimum 9 characters!')</script>";
			
			exit();
		}

		$check_email = "select * from user where email='$email'";
		$run_email = mysqli_query($con,$check_email);

		$check = mysqli_num_rows($run_email);

		if($check == 1){
			echo "<script>alert('Email already exist, Please try using another email')</script>";
			echo "<script>window.open('../View/register.php', '_self')</script>";
			exit();
		}

		
				$profile_pic = "head_red.jpg";
		

		$insert = "insert into user (f_name,l_name,gender,dob,address,email,phone,u_name,pass,picture)
		values('$first_name','$last_name','$gender','$birthday','$address','$email','$phone','$user_name','$pass','$paa')";

		$query = mysqli_query($con, $insert);

		if($query){
			echo "<script>alert('You are registered.')</script>";
			echo "<script>window.open('../View/signin.php', '_self')</script>";
		}
		else{
			echo "<script>alert('Registration failed, please try again!')</script>";
		  echo "<script>window.open('../View/register.php', '_self')</script>";
		}
	}
?>
